#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include "std_msgs/String.h"
#include "continuum_manipulator_visualization.cpp"
#include "continuum_manipulator_visualization.hpp"
#include <Eigen3/Eigen/Dense>
#include <Eigen3/Eigen/Core>

namespace muscle_ns{
Muscle::Muscle(ros::NodeHandle& nodeHandle) : nodeHandle(nodeHandle)
{
  muscle_pub=nodeHandle.advertise<visualization_msgs::Marker>("visualization_marker", 1);
  //muscle_sub=nodeHandle.subscribe("/winkelref", 1 , &Muscle::muscleCallback, this);
  m_length_sub = nodeHandle.subscribe("/laengen", 1 , &Muscle::lengthCallback, this);
  initializeMatrices();

  //initializeMatrices();


}
} /*namespace*/

int main( int argc, char** argv )
{
  ros::init(argc, argv, "continuum_manipulator_visualization");
  ros::NodeHandle nodeHandle("~");

muscle_ns:: Muscle muscle0(nodeHandle);
  ros::Rate r(300);

  while(ros::ok())  {
    ros::spinOnce();
    r.sleep();
  }

  return 0;
}
